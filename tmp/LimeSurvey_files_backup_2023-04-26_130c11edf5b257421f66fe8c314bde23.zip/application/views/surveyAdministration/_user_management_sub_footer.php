<div class="row sub_footer">
  <div class="col-12 mt-5 mb-3">
    <div style="border-top:1px solid #1E1E1E"></div>
  </div>

  <div class="col-lg-6 col-12 d-flex ls-footer-label">
    <i class="ri-information-line me-2"></i>
    <p class="me-1">ᴵ</p>
    <div>
      <?= gT(" Go to") ?>
      <a href="<?php echo $this->createUrl('userManagement/index'); ?>" target="_blank"> 
        <?= gT(" global user management ") ?></a> <?= gT("for general user management (add/edit/delete general users).") ?>
      <?= gT("If you don't have permission please contact your administrator.") ?>
    </div>
  </div>
</div>