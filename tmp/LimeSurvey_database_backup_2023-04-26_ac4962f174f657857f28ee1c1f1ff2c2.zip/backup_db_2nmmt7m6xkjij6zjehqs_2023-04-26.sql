-- Only prefixed tables with: lime_
-- Date of Dump: 26-Apr-2023
--

-- --------------------------------------------------------

--
-- Table structure for table `lime_answer_l10ns`
--

DROP TABLE IF EXISTS `lime_answer_l10ns`;
CREATE TABLE `lime_answer_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `answer` mediumtext NOT NULL,
  `language` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_answer_l10ns_idx` (`aid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_answer_l10ns`
--

INSERT INTO `lime_answer_l10ns` (`id`,`aid`,`answer`,`language`) VALUES
(1, 1, 'гравитация', 'ru'),
(2, 2, 'бог', 'ru'),
(3, 3, 'вселенная', 'ru');


-- --------------------------------------------------------

--
-- Table structure for table `lime_answers`
--

DROP TABLE IF EXISTS `lime_answers`;
CREATE TABLE `lime_answers` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT 0,
  `scale_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`aid`),
  UNIQUE KEY `lime_answers_idx` (`qid`,`code`,`scale_id`),
  KEY `lime_answers_idx2` (`sortorder`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_answers`
--

INSERT INTO `lime_answers` (`aid`,`qid`,`code`,`sortorder`,`assessment_value`,`scale_id`) VALUES
(1, 3, 'AO01', 0, 0, 0),
(2, 3, 'AO02', 1, 0, 0),
(3, 3, 'AO03', 2, 0, 0);


-- --------------------------------------------------------

--
-- Table structure for table `lime_archived_table_settings`
--

DROP TABLE IF EXISTS `lime_archived_table_settings`;
CREATE TABLE `lime_archived_table_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tbl_name` varchar(255) NOT NULL,
  `tbl_type` varchar(10) NOT NULL,
  `created` datetime NOT NULL,
  `properties` text NOT NULL,
  `attributes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_archived_table_settings`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_assessments`
--

DROP TABLE IF EXISTS `lime_assessments`;
CREATE TABLE `lime_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT 0,
  `scope` varchar(5) NOT NULL,
  `gid` int(11) NOT NULL DEFAULT 0,
  `name` text NOT NULL,
  `minimum` varchar(50) NOT NULL,
  `maximum` varchar(50) NOT NULL,
  `message` mediumtext NOT NULL,
  `language` varchar(20) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`,`language`),
  KEY `lime_assessments_idx2` (`sid`),
  KEY `lime_assessments_idx3` (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_assessments`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_asset_version`
--

DROP TABLE IF EXISTS `lime_asset_version`;
CREATE TABLE `lime_asset_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_asset_version`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_boxes`
--

DROP TABLE IF EXISTS `lime_boxes`;
CREATE TABLE `lime_boxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `url` text NOT NULL,
  `title` text NOT NULL,
  `buttontext` varchar(255) DEFAULT NULL,
  `ico` varchar(255) DEFAULT NULL,
  `desc` text NOT NULL,
  `page` text NOT NULL,
  `usergroup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_boxes`
--

INSERT INTO `lime_boxes` (`id`,`position`,`url`,`title`,`buttontext`,`ico`,`desc`,`page`,`usergroup`) VALUES
(1, 1, 'surveyAdministration/newSurvey', 'Create survey', 'Create survey', 'ri-add-line', 'Create a new survey from scratch. Or simply copy or import an existing survey.', 'welcome', -2),
(2, 2, 'surveyAdministration/listsurveys', 'List surveys', NULL, 'ri-list-unordered', 'List available surveys', 'welcome', -1),
(3, 3, 'admin/globalsettings', 'Global settings', 'View global settings', 'ri-settings-5-line', 'Edit global settings', 'welcome', -2),
(4, 4, 'userManagement/index', 'Manage survey administrators', 'Manage administrators', 'ri-user-line', 'The user management allows you to add additional users to your survey site.', 'welcome', -2),
(5, 5, 'admin/labels/sa/view', 'Label sets', 'Edit label sets', 'ri-price-tag-3-line', 'Label sets are templayes which can be loaded in most question types to speed up.', 'welcome', -2),
(6, 6, 'themeOptions', 'Themes', 'Edit themes', 'ri-brush-line', 'The themes functionality allows you to edit survey-, admin- or question themes.', 'welcome', -2);


-- --------------------------------------------------------

--
-- Table structure for table `lime_conditions`
--

DROP TABLE IF EXISTS `lime_conditions`;
CREATE TABLE `lime_conditions` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT 0,
  `cqid` int(11) NOT NULL DEFAULT 0,
  `cfieldname` varchar(50) NOT NULL DEFAULT '',
  `method` varchar(5) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `scenario` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`cid`),
  KEY `lime_conditions_idx` (`qid`),
  KEY `lime_conditions_idx3` (`cqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_conditions`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_defaultvalue_l10ns`
--

DROP TABLE IF EXISTS `lime_defaultvalue_l10ns`;
CREATE TABLE `lime_defaultvalue_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dvid` int(11) NOT NULL DEFAULT 0,
  `language` varchar(20) NOT NULL,
  `defaultvalue` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_defaultvalue_ls` (`dvid`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_defaultvalue_l10ns`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_defaultvalues`
--

DROP TABLE IF EXISTS `lime_defaultvalues`;
CREATE TABLE `lime_defaultvalues` (
  `dvid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT 0,
  `scale_id` int(11) NOT NULL DEFAULT 0,
  `sqid` int(11) NOT NULL DEFAULT 0,
  `specialtype` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`dvid`),
  KEY `lime_idx1_defaultvalue` (`qid`,`scale_id`,`sqid`,`specialtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_defaultvalues`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_expression_errors`
--

DROP TABLE IF EXISTS `lime_expression_errors`;
CREATE TABLE `lime_expression_errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errortime` varchar(50) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `gseq` int(11) DEFAULT NULL,
  `qseq` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `eqn` text DEFAULT NULL,
  `prettyprint` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_expression_errors`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_failed_emails`
--

DROP TABLE IF EXISTS `lime_failed_emails`;
CREATE TABLE `lime_failed_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `responseid` int(11) NOT NULL,
  `email_type` varchar(200) NOT NULL,
  `recipient` varchar(320) NOT NULL,
  `language` varchar(20) NOT NULL DEFAULT 'en',
  `error_message` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `status` varchar(20) DEFAULT 'SEND FAILED',
  `updated` datetime DEFAULT NULL,
  `resend_vars` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_failed_emails`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_failed_login_attempts`
--

DROP TABLE IF EXISTS `lime_failed_login_attempts`;
CREATE TABLE `lime_failed_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) NOT NULL,
  `last_attempt` varchar(20) NOT NULL,
  `number_attempts` int(11) NOT NULL,
  `is_frontend` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_failed_login_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_group_l10ns`
--

DROP TABLE IF EXISTS `lime_group_l10ns`;
CREATE TABLE `lime_group_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `group_name` text NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `language` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_idx1_group_ls` (`gid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_group_l10ns`
--

INSERT INTO `lime_group_l10ns` (`id`,`gid`,`group_name`,`description`,`language`) VALUES
(1, 1, 'Моя первая группа вопросов', NULL, 'ru'),
(2, 2, 'Моя первая группа вопросов', NULL, 'ru'),
(3, 3, 'Группа тестов', '', 'ru');


-- --------------------------------------------------------

--
-- Table structure for table `lime_groups`
--

DROP TABLE IF EXISTS `lime_groups`;
CREATE TABLE `lime_groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT 0,
  `group_order` int(11) NOT NULL DEFAULT 0,
  `randomization_group` varchar(20) NOT NULL DEFAULT '',
  `grelevance` text DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `lime_idx1_groups` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_groups`
--

INSERT INTO `lime_groups` (`gid`,`sid`,`group_order`,`randomization_group`,`grelevance`) VALUES
(1, 254951, 1, '', '1'),
(2, 779317, 1, '', '1'),
(3, 779317, 2, '', '');


-- --------------------------------------------------------

--
-- Table structure for table `lime_label_l10ns`
--

DROP TABLE IF EXISTS `lime_label_l10ns`;
CREATE TABLE `lime_label_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_id` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `language` varchar(20) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_label_l10ns`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_labels`
--

DROP TABLE IF EXISTS `lime_labels`;
CREATE TABLE `lime_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL DEFAULT 0,
  `code` varchar(20) NOT NULL DEFAULT '',
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_idx5_labels` (`lid`,`code`),
  KEY `lime_idx1_labels` (`code`),
  KEY `lime_idx2_labels` (`sortorder`),
  KEY `lime_idx4_labels` (`lid`,`sortorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_labels`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_labelsets`
--

DROP TABLE IF EXISTS `lime_labelsets`;
CREATE TABLE `lime_labelsets` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(100) NOT NULL DEFAULT '',
  `languages` varchar(255) NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_labelsets`
--

INSERT INTO `lime_labelsets` (`lid`,`label_name`,`languages`) VALUES
(1, 'Test', 'ru'),
(2, 'Test2', 'ru');


-- --------------------------------------------------------

--
-- Table structure for table `lime_map_tutorial_users`
--

DROP TABLE IF EXISTS `lime_map_tutorial_users`;
CREATE TABLE `lime_map_tutorial_users` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `taken` int(11) DEFAULT 1,
  PRIMARY KEY (`uid`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_map_tutorial_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_message`
--

DROP TABLE IF EXISTS `lime_message`;
CREATE TABLE `lime_message` (
  `id` int(11) NOT NULL,
  `language` varchar(50) NOT NULL DEFAULT '',
  `translation` text DEFAULT NULL,
  PRIMARY KEY (`id`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_notifications`
--

DROP TABLE IF EXISTS `lime_notifications`;
CREATE TABLE `lime_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(15) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'new',
  `importance` int(11) NOT NULL DEFAULT 1,
  `display_class` varchar(31) DEFAULT 'default',
  `hash` varchar(64) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `first_read` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_notifications_pk` (`entity`,`entity_id`,`status`),
  KEY `lime_idx1_notifications` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_notifications`
--

INSERT INTO `lime_notifications` (`id`,`entity`,`entity_id`,`title`,`message`,`status`,`importance`,`display_class`,`hash`,`created`,`first_read`) VALUES
(3, 'user', 1, 'Использование SSL не включено', '<span class=\"ri-error-warning-fill\"></span>&nbsp;Предупреждение: Включите принудительное шифрование SSL в меню Общие настройки / Безопасность после соответствующей настройки SSL на Вашем сервере.', 'new', 1, 'default', '5c8d06b6cd3cc4adc0e75d0eb4ef23f0c9fd42d3422bd8a4b12737d2f8bc1ed6', '2023-04-25 22:50:51', '2023-04-26 20:08:02');


-- --------------------------------------------------------

--
-- Table structure for table `lime_participant_attribute`
--

DROP TABLE IF EXISTS `lime_participant_attribute`;
CREATE TABLE `lime_participant_attribute` (
  `participant_id` varchar(50) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`participant_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participant_attribute`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_participant_attribute_names`
--

DROP TABLE IF EXISTS `lime_participant_attribute_names`;
CREATE TABLE `lime_participant_attribute_names` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_type` varchar(4) NOT NULL,
  `defaultname` varchar(255) NOT NULL,
  `visible` varchar(5) NOT NULL,
  `encrypted` varchar(5) NOT NULL,
  `core_attribute` varchar(5) NOT NULL,
  PRIMARY KEY (`attribute_id`,`attribute_type`),
  KEY `lime_idx_participant_attribute_names` (`attribute_id`,`attribute_type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participant_attribute_names`
--

INSERT INTO `lime_participant_attribute_names` (`attribute_id`,`attribute_type`,`defaultname`,`visible`,`encrypted`,`core_attribute`) VALUES
(1, 'TB', 'firstname', 'TRUE', 'Y', 'Y'),
(2, 'TB', 'lastname', 'TRUE', 'Y', 'Y'),
(3, 'TB', 'email', 'TRUE', 'Y', 'Y');


-- --------------------------------------------------------

--
-- Table structure for table `lime_participant_attribute_names_lang`
--

DROP TABLE IF EXISTS `lime_participant_attribute_names_lang`;
CREATE TABLE `lime_participant_attribute_names_lang` (
  `attribute_id` int(11) NOT NULL,
  `attribute_name` varchar(255) NOT NULL,
  `lang` varchar(20) NOT NULL,
  PRIMARY KEY (`attribute_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participant_attribute_names_lang`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_participant_attribute_values`
--

DROP TABLE IF EXISTS `lime_participant_attribute_values`;
CREATE TABLE `lime_participant_attribute_values` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participant_attribute_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_participant_shares`
--

DROP TABLE IF EXISTS `lime_participant_shares`;
CREATE TABLE `lime_participant_shares` (
  `participant_id` varchar(50) NOT NULL,
  `share_uid` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `can_edit` varchar(5) NOT NULL,
  PRIMARY KEY (`participant_id`,`share_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participant_shares`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_participants`
--

DROP TABLE IF EXISTS `lime_participants`;
CREATE TABLE `lime_participants` (
  `participant_id` varchar(50) NOT NULL,
  `firstname` text DEFAULT NULL,
  `lastname` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `blacklisted` varchar(1) NOT NULL,
  `owner_uid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `lime_idx3_participants` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_participants`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_permissions`
--

DROP TABLE IF EXISTS `lime_permissions`;
CREATE TABLE `lime_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `permission` varchar(100) NOT NULL,
  `create_p` int(11) NOT NULL DEFAULT 0,
  `read_p` int(11) NOT NULL DEFAULT 0,
  `update_p` int(11) NOT NULL DEFAULT 0,
  `delete_p` int(11) NOT NULL DEFAULT 0,
  `import_p` int(11) NOT NULL DEFAULT 0,
  `export_p` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_idx1_permissions` (`entity_id`,`entity`,`permission`,`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_permissions`
--

INSERT INTO `lime_permissions` (`id`,`entity`,`entity_id`,`uid`,`permission`,`create_p`,`read_p`,`update_p`,`delete_p`,`import_p`,`export_p`) VALUES
(1, 'global', 0, 1, 'superadmin', 0, 1, 0, 0, 0, 0),
(2, 'survey', 254951, 1, 'assessments', 1, 1, 1, 1, 0, 0),
(3, 'survey', 254951, 1, 'quotas', 1, 1, 1, 1, 0, 0),
(4, 'survey', 254951, 1, 'responses', 1, 1, 1, 1, 1, 1),
(5, 'survey', 254951, 1, 'statistics', 0, 1, 0, 0, 0, 0),
(6, 'survey', 254951, 1, 'survey', 0, 1, 0, 1, 0, 0),
(7, 'survey', 254951, 1, 'surveyactivation', 0, 0, 1, 0, 0, 0),
(8, 'survey', 254951, 1, 'surveycontent', 1, 1, 1, 1, 1, 1),
(9, 'survey', 254951, 1, 'surveylocale', 0, 1, 1, 0, 0, 0),
(10, 'survey', 254951, 1, 'surveysecurity', 1, 1, 1, 1, 0, 0),
(11, 'survey', 254951, 1, 'surveysettings', 0, 1, 1, 0, 0, 0),
(12, 'survey', 254951, 1, 'tokens', 1, 1, 1, 1, 1, 1),
(13, 'survey', 254951, 1, 'translations', 0, 1, 1, 0, 0, 0),
(14, 'survey', 779317, 1, 'assessments', 1, 1, 1, 1, 0, 0),
(15, 'survey', 779317, 1, 'quotas', 1, 1, 1, 1, 0, 0),
(16, 'survey', 779317, 1, 'responses', 1, 1, 1, 1, 1, 1),
(17, 'survey', 779317, 1, 'statistics', 0, 1, 0, 0, 0, 0),
(18, 'survey', 779317, 1, 'survey', 0, 1, 0, 1, 0, 0),
(19, 'survey', 779317, 1, 'surveyactivation', 0, 0, 1, 0, 0, 0),
(20, 'survey', 779317, 1, 'surveycontent', 1, 1, 1, 1, 1, 1),
(21, 'survey', 779317, 1, 'surveylocale', 0, 1, 1, 0, 0, 0),
(22, 'survey', 779317, 1, 'surveysecurity', 1, 1, 1, 1, 0, 0),
(23, 'survey', 779317, 1, 'surveysettings', 0, 1, 1, 0, 0, 0),
(24, 'survey', 779317, 1, 'tokens', 1, 1, 1, 1, 1, 1),
(25, 'survey', 779317, 1, 'translations', 0, 1, 1, 0, 0, 0);


-- --------------------------------------------------------

--
-- Table structure for table `lime_permissiontemplates`
--

DROP TABLE IF EXISTS `lime_permissiontemplates`;
CREATE TABLE `lime_permissiontemplates` (
  `ptid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(127) NOT NULL,
  `description` text DEFAULT NULL,
  `renewed_last` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`ptid`),
  UNIQUE KEY `lime_idx1_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_permissiontemplates`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_plugin_settings`
--

DROP TABLE IF EXISTS `lime_plugin_settings`;
CREATE TABLE `lime_plugin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_id` int(11) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `key` varchar(50) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_plugin_settings`
--

INSERT INTO `lime_plugin_settings` (`id`,`plugin_id`,`model`,`model_id`,`key`,`value`) VALUES
(1, 1, NULL, NULL, 'next_extension_update_check', '\"2023-04-26 17:09:35\"');


-- --------------------------------------------------------

--
-- Table structure for table `lime_plugins`
--

DROP TABLE IF EXISTS `lime_plugins`;
CREATE TABLE `lime_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `plugin_type` varchar(6) DEFAULT 'user',
  `active` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) NOT NULL DEFAULT 0,
  `version` varchar(32) DEFAULT NULL,
  `load_error` int(11) DEFAULT 0,
  `load_error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_plugins`
--

INSERT INTO `lime_plugins` (`id`,`name`,`plugin_type`,`active`,`priority`,`version`,`load_error`,`load_error_message`) VALUES
(1, 'UpdateCheck', 'core', 1, 0, '1.0.0', 0, NULL),
(2, 'PasswordRequirement', 'core', 1, 0, '1.1.0', 1, 'Class \"Learns\\PluginManager\\PluginBase\" not found D:\\xamp\\htdocs\\learns\\application\\core\\plugins\\PasswordRequirement\\PasswordRequirement.php'),
(3, 'ComfortUpdateChecker', 'core', 1, 0, '1.0.0', 0, NULL),
(4, 'Authdb', 'core', 1, 0, '1.0.0', 0, NULL),
(5, 'AuthLDAP', 'core', 0, 0, '1.0.0', 0, NULL),
(6, 'AuditLog', 'core', 0, 0, '1.0.0', 0, NULL),
(7, 'Authwebserver', 'core', 0, 0, '1.0.0', 0, NULL),
(8, 'ExportR', 'core', 1, 0, '1.0.0', 1, 'Class \"Learns\\PluginManager\\PluginBase\" not found D:\\xamp\\htdocs\\learns\\application\\core\\plugins\\ExportR\\ExportR.php'),
(9, 'ExportSTATAxml', 'core', 1, 0, '1.0.0', 1, 'Class \"Learns\\PluginManager\\PluginBase\" not found D:\\xamp\\htdocs\\learns\\application\\core\\plugins\\ExportSTATAxml\\ExportSTATAxml.php'),
(10, 'ExportSPSSsav', 'core', 1, 0, '1.0.4', 1, 'Class \"Learns\\PluginManager\\PluginBase\" not found D:\\xamp\\htdocs\\learns\\application\\core\\plugins\\ExportSPSSsav\\ExportSPSSsav.php'),
(11, 'oldUrlCompat', 'core', 0, 0, '1.0.1', 0, NULL),
(12, 'expressionQuestionHelp', 'core', 0, 0, '1.0.1', 0, NULL),
(13, 'expressionQuestionForAll', 'core', 0, 0, '1.0.1', 0, NULL),
(14, 'expressionFixedDbVar', 'core', 0, 0, '1.0.2', 0, NULL),
(15, 'customToken', 'core', 0, 0, '1.0.1', 0, NULL),
(16, 'mailSenderToFrom', 'core', 0, 0, '1.0.0', 0, NULL),
(17, 'TwoFactorAdminLogin', 'core', 0, 0, '1.2.5', 0, NULL);


-- --------------------------------------------------------

--
-- Table structure for table `lime_question_attributes`
--

DROP TABLE IF EXISTS `lime_question_attributes`;
CREATE TABLE `lime_question_attributes` (
  `qaid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT 0,
  `attribute` varchar(50) DEFAULT NULL,
  `value` mediumtext DEFAULT NULL,
  `language` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`qaid`),
  KEY `lime_idx1_question_attributes` (`qid`),
  KEY `lime_idx2_question_attributes` (`attribute`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_question_attributes`
--

INSERT INTO `lime_question_attributes` (`qaid`,`qid`,`attribute`,`value`,`language`) VALUES
(1, 3, 'array_filter', '', ''),
(2, 3, 'array_filter_style', '0', ''),
(3, 3, 'array_filter_exclude', '', ''),
(4, 3, 'other_numbers_only', '0', ''),
(5, 3, 'other_comment_mandatory', '0', ''),
(6, 3, 'random_group', '', ''),
(7, 3, 'em_validation_q', '', ''),
(8, 3, 'em_validation_q_tip', '', 'ru'),
(9, 3, 'answer_order', 'random', ''),
(10, 3, 'other_replace_text', '', 'ru'),
(11, 3, 'hide_tip', '0', ''),
(12, 3, 'display_columns', '', ''),
(13, 3, 'hidden', '0', ''),
(14, 3, 'cssclass', '', ''),
(15, 3, 'other_position', 'default', ''),
(16, 3, 'other_position_code', '', ''),
(17, 3, 'printable_help', '', 'ru'),
(18, 3, 'page_break', '0', ''),
(19, 3, 'scale_export', '0', ''),
(20, 3, 'time_limit', '', ''),
(21, 3, 'time_limit_action', '1', ''),
(22, 3, 'time_limit_disable_next', '0', ''),
(23, 3, 'time_limit_disable_prev', '0', ''),
(24, 3, 'time_limit_countdown_message', '', 'ru'),
(25, 3, 'time_limit_timer_style', '', ''),
(26, 3, 'time_limit_message_delay', '', ''),
(27, 3, 'time_limit_message', '', 'ru'),
(28, 3, 'time_limit_message_style', '', ''),
(29, 3, 'time_limit_warning', '', ''),
(30, 3, 'time_limit_warning_display_time', '', ''),
(31, 3, 'time_limit_warning_message', '', 'ru'),
(32, 3, 'time_limit_warning_style', '', ''),
(33, 3, 'time_limit_warning_2', '', ''),
(34, 3, 'time_limit_warning_2_display_time', '', ''),
(35, 3, 'time_limit_warning_2_message', '', 'ru'),
(36, 3, 'time_limit_warning_2_style', '', ''),
(37, 3, 'public_statistics', '0', ''),
(38, 3, 'statistics_showgraph', '1', ''),
(39, 3, 'statistics_graphtype', '0', ''),
(40, 3, 'save_as_default', 'N', ''),
(41, 4, 'random_group', '', ''),
(42, 4, 'em_validation_q', '', ''),
(43, 4, 'em_validation_q_tip', '', 'ru'),
(44, 4, 'slider_rating', '0', ''),
(45, 4, 'hide_tip', '0', ''),
(46, 4, 'hidden', '0', ''),
(47, 4, 'cssclass', '', ''),
(48, 4, 'printable_help', '', 'ru'),
(49, 4, 'page_break', '0', ''),
(50, 4, 'public_statistics', '0', ''),
(51, 4, 'statistics_showgraph', '1', ''),
(52, 4, 'statistics_graphtype', '0', ''),
(53, 4, 'save_as_default', 'N', '');


-- --------------------------------------------------------

--
-- Table structure for table `lime_question_l10ns`
--

DROP TABLE IF EXISTS `lime_question_l10ns`;
CREATE TABLE `lime_question_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `question` mediumtext NOT NULL,
  `help` mediumtext DEFAULT NULL,
  `script` text DEFAULT NULL,
  `language` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_idx1_question_ls` (`qid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_question_l10ns`
--

INSERT INTO `lime_question_l10ns` (`id`,`qid`,`question`,`help`,`script`,`language`) VALUES
(1, 1, 'Пример первого вопроса. Пожалуйста, ответьте на вопрос: ', 'Это текст подсказки к вопросу.', NULL, 'ru'),
(3, 3, '<span style=\"font-family:Times New Roman,Times,serif;\">Почему земля круглая?</span>\r\n<div class=\"notranslate\" style=\"all: initial;\"> </div>\r\n', '', '', 'ru'),
(4, 4, 'Как сделать сайт?', '', '', 'ru');


-- --------------------------------------------------------

--
-- Table structure for table `lime_question_themes`
--

DROP TABLE IF EXISTS `lime_question_themes`;
CREATE TABLE `lime_question_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `visible` varchar(1) DEFAULT NULL,
  `xml_path` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `author` varchar(150) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `author_url` varchar(255) DEFAULT NULL,
  `copyright` text DEFAULT NULL,
  `license` text DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `api_version` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `theme_type` varchar(150) DEFAULT NULL,
  `question_type` varchar(150) NOT NULL,
  `core_theme` tinyint(1) DEFAULT NULL,
  `extends` varchar(150) DEFAULT NULL,
  `group` varchar(150) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_question_themes` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_question_themes`
--

INSERT INTO `lime_question_themes` (`id`,`name`,`visible`,`xml_path`,`image_path`,`title`,`creation_date`,`author`,`author_email`,`author_url`,`copyright`,`license`,`version`,`api_version`,`description`,`last_update`,`owner_id`,`theme_type`,`question_type`,`core_theme`,`extends`,`group`,`settings`) VALUES
(1, '5pointchoice', 'Y', 'application/views/survey/questions/answer/5pointchoice', '/assets/images/screenshots/5.png', '5 point choice', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', '5 point choice question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', '5', 1, '', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"choice-5-pt-radio\"}'),
(2, 'arrays/10point', 'Y', 'application/views/survey/questions/answer/arrays/10point', '/assets/images/screenshots/B.png', 'Array (10 point choice)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (10 point choice) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'B', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-10-pt\"}'),
(3, 'arrays/5point', 'Y', 'application/views/survey/questions/answer/arrays/5point', '/assets/images/screenshots/A.png', 'Array (5 point choice)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (5 point choice) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'A', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-5-pt\"}'),
(4, 'arrays/array', 'Y', 'application/views/survey/questions/answer/arrays/array', '/assets/images/screenshots/F.png', 'Array', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'F', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-row\"}'),
(5, 'arrays/column', 'Y', 'application/views/survey/questions/answer/arrays/column', '/assets/images/screenshots/H.png', 'Array by column', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array by column question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'H', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-column\"}'),
(6, 'arrays/dualscale', 'Y', 'application/views/survey/questions/answer/arrays/dualscale', '/assets/images/screenshots/1.png', 'Array dual scale', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array dual scale question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', '1', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"2\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-dual-scale\"}'),
(7, 'arrays/increasesamedecrease', 'Y', 'application/views/survey/questions/answer/arrays/increasesamedecrease', '/assets/images/screenshots/E.png', 'Array (Increase/Same/Decrease)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (Increase/Same/Decrease) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'E', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-increase-same-decrease\"}'),
(8, 'arrays/multiflexi', 'Y', 'application/views/survey/questions/answer/arrays/multiflexi', '/assets/images/screenshots/COLON.png', 'Array (Numbers)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (Numbers) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', ':', 1, '', 'Arrays', '{\"subquestions\":\"2\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-multi-flexi\"}'),
(9, 'arrays/texts', 'Y', 'application/views/survey/questions/answer/arrays/texts', '/assets/images/screenshots/;.png', 'Array (Texts)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (Texts) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', ';', 1, '', 'Arrays', '{\"subquestions\":\"2\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"array-multi-flexi-text\"}'),
(10, 'arrays/yesnouncertain', 'Y', 'application/views/survey/questions/answer/arrays/yesnouncertain', '/assets/images/screenshots/C.png', 'Array (Yes/No/Uncertain)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Array (Yes/No/Uncertain) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'C', 1, '', 'Arrays', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-yes-uncertain-no\"}'),
(11, 'boilerplate', 'Y', 'application/views/survey/questions/answer/boilerplate', '/assets/images/screenshots/X.png', 'Text display', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Text display question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'X', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"boilerplate\"}'),
(12, 'date', 'Y', 'application/views/survey/questions/answer/date', '/assets/images/screenshots/D.png', 'Date/Time', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Date/Time question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'D', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"date\"}'),
(13, 'equation', 'Y', 'application/views/survey/questions/answer/equation', '/assets/images/screenshots/EQUATION.png', 'Equation', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Equation question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', '*', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"equation\"}'),
(14, 'file_upload', 'Y', 'application/views/survey/questions/answer/file_upload', '/assets/images/screenshots/PIPE.png', 'File upload', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'File upload question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', '|', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"upload-files\"}'),
(15, 'gender', 'Y', 'application/views/survey/questions/answer/gender', '/assets/images/screenshots/G.png', 'Gender', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Gender question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'G', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"gender\"}'),
(16, 'hugefreetext', 'Y', 'application/views/survey/questions/answer/hugefreetext', '/assets/images/screenshots/U.png', 'Huge free text', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Huge free text question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'U', 1, '', 'Text questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-huge\"}'),
(17, 'language', 'Y', 'application/views/survey/questions/answer/language', '/assets/images/screenshots/I.png', 'Language switch', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Language switch question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'I', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"language\"}'),
(18, 'listradio', 'Y', 'application/views/survey/questions/answer/listradio', '/assets/images/screenshots/L.png', 'List (Radio)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'List (radio) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'L', 1, '', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),
(19, 'list_dropdown', 'Y', 'application/views/survey/questions/answer/list_dropdown', '/assets/images/screenshots/!.png', 'List (Dropdown)', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'List (dropdown) question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', '!', 1, '', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-dropdown\"}'),
(20, 'list_with_comment', 'Y', 'application/views/survey/questions/answer/list_with_comment', '/assets/images/screenshots/O.png', 'List with comment', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'List with comment question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'O', 1, '', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-with-comment\"}'),
(21, 'longfreetext', 'Y', 'application/views/survey/questions/answer/longfreetext', '/assets/images/screenshots/T.png', 'Long free text', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Long free text question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'T', 1, '', 'Text questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-long\"}'),
(22, 'multiplechoice', 'Y', 'application/views/survey/questions/answer/multiplechoice', '/assets/images/screenshots/M.png', 'Multiple choice', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Multiple choice question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'M', 1, '', 'Multiple choice questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),
(23, 'multiplechoice_with_comments', 'Y', 'application/views/survey/questions/answer/multiplechoice_with_comments', '/assets/images/screenshots/P.png', 'Multiple choice with comments', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Multiple choice with comments question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'P', 1, '', 'Multiple choice questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt-comments\"}'),
(24, 'multiplenumeric', 'Y', 'application/views/survey/questions/answer/multiplenumeric', '/assets/images/screenshots/K.png', 'Multiple numerical input', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Multiple numerical input question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'K', 1, '', 'Mask questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"numeric-multi\"}'),
(25, 'multipleshorttext', 'Y', 'application/views/survey/questions/answer/multipleshorttext', '/assets/images/screenshots/Q.png', 'Multiple short text', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Multiple short text question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'Q', 1, '', 'Text questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"multiple-short-txt\"}'),
(26, 'numerical', 'Y', 'application/views/survey/questions/answer/numerical', '/assets/images/screenshots/N.png', 'Numerical input', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Numerical input question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'N', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"numeric\"}'),
(27, 'ranking', 'Y', 'application/views/survey/questions/answer/ranking', '/assets/images/screenshots/R.png', 'Ranking', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Ranking question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'R', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"ranking\"}'),
(28, 'shortfreetext', 'Y', 'application/views/survey/questions/answer/shortfreetext', '/assets/images/screenshots/S.png', 'Short free text', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Short free text question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'S', 1, '', 'Text questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-short\"}'),
(29, 'yesno', 'Y', 'application/views/survey/questions/answer/yesno', '/assets/images/screenshots/Y.png', 'Yes/No', '2018-09-08 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Yes/No question type configuration', '2019-09-23 15:05:59', 1, 'question_theme', 'Y', 1, '', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"yes-no\"}'),
(30, 'bootstrap_dropdown', 'Y', 'themes/question/bootstrap_dropdown/survey/questions/answer/list_dropdown', '/themes/question/bootstrap_dropdown/survey/questions/answer/list_dropdown/assets/bootstrap_dropdown_list_dropdown.png', 'Bootstrap dropdown', '1970-01-01 01:00:00', 'Adam Zammit', 'adam.zammit@acspri.org.au', 'https://www.acspri.org.au', 'Copyright (C) 2021 The Australian Consortium for Social and Political Research Incorporated (ACSPRI)', 'GNU General Public License version 2 or later', '1.0', '1', 'Bootstrap dropdown theme', '2021-09-29 12:00:00', 1, 'question_theme', '!', 1, '!', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-dropdown\"}'),
(31, 'bootstrap_buttons', 'Y', 'themes/question/bootstrap_buttons/survey/questions/answer/listradio', '/themes/question/bootstrap_buttons/survey/questions/answer/listradio/assets/bootstrap_buttons_listradio.png', 'Bootstrap buttons', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'New implementation of the Bootstrap buttons question theme', '2019-09-23 15:05:59', 1, 'question_theme', 'L', 1, 'L', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),
(32, 'bootstrap_buttons_multi', 'Y', 'themes/question/bootstrap_buttons_multi/survey/questions/answer/multiplechoice', '/themes/question/bootstrap_buttons_multi/survey/questions/answer/multiplechoice/assets/bootstrap_buttons_multiplechoice.png', 'Bootstrap buttons', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'New implementation of the Bootstrap buttons question theme', '2019-09-23 15:05:59', 1, 'question_theme', 'M', 1, 'M', 'Multiple choice questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),
(33, 'browserdetect', 'Y', 'themes/question/browserdetect/survey/questions/answer/shortfreetext', '/assets/images/screenshots/S.png', 'Browser detection', '2017-07-09 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2017 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Browser, Platform and Proxy detection', '2019-09-23 15:05:59', 1, 'question_theme', 'S', 1, 'S', 'Text questions', '{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-short\"}'),
(34, 'image_select-listradio', 'Y', 'themes/question/image_select/survey/questions/answer/listradio', '/assets/images/screenshots/L.png', 'Image select list (Radio)', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2016 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'List Radio with images.', '2019-09-23 15:05:59', 1, 'question_theme', 'L', 1, 'L', 'Single choice questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),
(35, 'image_select-multiplechoice', 'Y', 'themes/question/image_select/survey/questions/answer/multiplechoice', '/assets/images/screenshots/M.png', 'Image select multiple choice', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2016 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Multiplechoice with images.', '2019-09-23 15:05:59', 1, 'question_theme', 'M', 1, 'M', 'Multiple choice questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),
(36, 'inputondemand', 'Y', 'themes/question/inputondemand/survey/questions/answer/multipleshorttext', '/assets/images/screenshots/Q.png', 'Input on demand', '2019-10-04 00:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2019 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'Hide not needed input fields in multiple shorttext', '2019-09-23 15:05:59', 1, 'question_theme', 'Q', 1, 'Q', 'Text questions', '{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"multiple-short-txt\"}'),
(37, 'ranking_advanced', 'Y', 'themes/question/ranking_advanced/survey/questions/answer/ranking', '/assets/images/screenshots/R.png', 'Ranking advanced', '1970-01-01 01:00:00', 'LimeSurvey GmbH', 'info@limesurvey.org', 'http://www.limesurvey.org', 'Copyright (C) 2005 - 2017 LimeSurvey Gmbh, Inc. All rights reserved.', 'GNU General Public License version 2 or later', '1.0', '1', 'New implementation of the ranking question', '2019-09-23 15:05:59', 1, 'question_theme', 'R', 1, 'R', 'Mask questions', '{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"ranking\"}');


-- --------------------------------------------------------

--
-- Table structure for table `lime_questions`
--

DROP TABLE IF EXISTS `lime_questions`;
CREATE TABLE `lime_questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_qid` int(11) NOT NULL DEFAULT 0,
  `sid` int(11) NOT NULL DEFAULT 0,
  `gid` int(11) NOT NULL DEFAULT 0,
  `type` varchar(30) NOT NULL DEFAULT 'T',
  `title` varchar(20) NOT NULL DEFAULT '',
  `preg` text DEFAULT NULL,
  `other` varchar(1) NOT NULL DEFAULT 'N',
  `mandatory` varchar(1) DEFAULT NULL,
  `encrypted` varchar(1) DEFAULT 'N',
  `question_order` int(11) NOT NULL,
  `scale_id` int(11) NOT NULL DEFAULT 0,
  `same_default` int(11) NOT NULL DEFAULT 0,
  `relevance` text DEFAULT NULL,
  `question_theme_name` varchar(150) DEFAULT NULL,
  `modulename` varchar(255) DEFAULT NULL,
  `same_script` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`qid`),
  KEY `lime_idx1_questions` (`sid`),
  KEY `lime_idx2_questions` (`gid`),
  KEY `lime_idx3_questions` (`type`),
  KEY `lime_idx4_questions` (`title`),
  KEY `lime_idx5_questions` (`parent_qid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_questions`
--

INSERT INTO `lime_questions` (`qid`,`parent_qid`,`sid`,`gid`,`type`,`title`,`preg`,`other`,`mandatory`,`encrypted`,`question_order`,`scale_id`,`same_default`,`relevance`,`question_theme_name`,`modulename`,`same_script`) VALUES
(1, 0, 254951, 1, 'T', 'Q00', NULL, 'N', 'N', 'N', 1, 0, 0, '1', 'longfreetext', NULL, 0),
(3, 0, 779317, 2, 'L', 'G01Q01', NULL, 'N', 'Y', 'N', 1, 0, 0, '1', 'listradio', '', 0),
(4, 0, 779317, 3, '5', 'G02Q02', NULL, 'N', 'N', 'N', 1, 0, 0, '1', '5pointchoice', '', 0);


-- --------------------------------------------------------

--
-- Table structure for table `lime_quota`
--

DROP TABLE IF EXISTS `lime_quota`;
CREATE TABLE `lime_quota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `qlimit` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `autoload_url` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_quota` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_quota`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_quota_languagesettings`
--

DROP TABLE IF EXISTS `lime_quota_languagesettings`;
CREATE TABLE `lime_quota_languagesettings` (
  `quotals_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotals_quota_id` int(11) NOT NULL DEFAULT 0,
  `quotals_language` varchar(45) NOT NULL DEFAULT 'en',
  `quotals_name` varchar(255) DEFAULT NULL,
  `quotals_message` mediumtext NOT NULL,
  `quotals_url` varchar(255) DEFAULT NULL,
  `quotals_urldescrip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`quotals_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_quota_languagesettings`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_quota_members`
--

DROP TABLE IF EXISTS `lime_quota_members`;
CREATE TABLE `lime_quota_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `quota_id` int(11) DEFAULT NULL,
  `code` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_idx1_quota_members` (`sid`,`qid`,`quota_id`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_quota_members`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_saved_control`
--

DROP TABLE IF EXISTS `lime_saved_control`;
CREATE TABLE `lime_saved_control` (
  `scid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT 0,
  `srid` int(11) NOT NULL DEFAULT 0,
  `identifier` text NOT NULL,
  `access_code` text NOT NULL,
  `email` varchar(192) DEFAULT NULL,
  `ip` text NOT NULL,
  `saved_thisstep` text NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT '',
  `saved_date` datetime NOT NULL,
  `refurl` text DEFAULT NULL,
  PRIMARY KEY (`scid`),
  KEY `lime_idx1_saved_control` (`sid`),
  KEY `lime_idx2_saved_control` (`srid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_saved_control`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_sessions`
--

DROP TABLE IF EXISTS `lime_sessions`;
CREATE TABLE `lime_sessions` (
  `id` varchar(32) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sess_expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_settings_global`
--

DROP TABLE IF EXISTS `lime_settings_global`;
CREATE TABLE `lime_settings_global` (
  `stg_name` varchar(50) NOT NULL DEFAULT '',
  `stg_value` mediumtext NOT NULL,
  PRIMARY KEY (`stg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_settings_global`
--

INSERT INTO `lime_settings_global` (`stg_name`,`stg_value`) VALUES
('sendadmincreationemail', '1'),
('admincreationemailsubject', 'Регистрация пользователей на \'{SITENAME}\''),
('admincreationemailtemplate', '<p>Привет {FULLNAME}, </p><p>Это автоматическое уведомление по электронной почте о том, что для вас создан пользователь на веб-сайте <strong>\'{SITENAME}\'</strong>.</p><p></p><p>Теперь вы можете использовать следующие учетные данные для входа в систему:</p><p><strong>Имя пользователя</strong>: {USERNAME}</p><p><a href=\"{LOGINURL}\">Нажмите здесь, чтобы установить пароль</a></p><p>Если у вас есть какие-либо вопросы относительно этого письма, обратитесь к администратору сайта по {SITEADMINEMAIL}.</p><p> </p><p>Спасибо!</p>'),
('DBVersion', '499'),
('SessionName', 'WBGJIKNGGIXVAKYPFSZEKZKPWXAFYLRFHXTUYLETTZKKERNTNLVHDQIBQHGOKJLF'),
('sitename', 'Learns'),
('siteadminname', 'Administrator'),
('siteadminemail', 'smagulovabilai7@gmail.com'),
('siteadminbounce', 'smagulovabilai7@gmail.com'),
('defaultlang', 'ru'),
('AssetsVersion', '30331'),
('last_survey_1', '254951'),
('show_survey_list', 'd-none'),
('boxes_in_container', 'yes'),
('boxes_by_row', '3'),
('boxes_offset', '3'),
('update_key', '32395PWE164');


-- --------------------------------------------------------

--
-- Table structure for table `lime_settings_user`
--

DROP TABLE IF EXISTS `lime_settings_user`;
CREATE TABLE `lime_settings_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `entity` varchar(15) DEFAULT NULL,
  `entity_id` varchar(31) DEFAULT NULL,
  `stg_name` varchar(63) NOT NULL,
  `stg_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_settings_user` (`uid`),
  KEY `lime_idx2_settings_user` (`entity`),
  KEY `lime_idx3_settings_user` (`entity_id`),
  KEY `lime_idx4_settings_user` (`stg_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_settings_user`
--

INSERT INTO `lime_settings_user` (`id`,`uid`,`entity`,`entity_id`,`stg_name`,`stg_value`) VALUES
(1, 1, NULL, NULL, 'quickaction_state', '1'),
(2, 1, NULL, NULL, 'lock_organizer', '1'),
(3, 1, NULL, NULL, 'preselectquestiontype', 'T'),
(4, 1, NULL, NULL, 'preselectquestiontheme', 'longfreetext'),
(5, 1, NULL, NULL, 'showScriptEdit', '1'),
(6, 1, NULL, NULL, 'noViewMode', '1'),
(7, 1, NULL, NULL, 'answeroptionprefix', 'AO'),
(8, 1, NULL, NULL, 'subquestionprefix', 'SQ'),
(9, 1, NULL, NULL, 'createsample', 'default');


-- --------------------------------------------------------

--
-- Table structure for table `lime_source_message`
--

DROP TABLE IF EXISTS `lime_source_message`;
CREATE TABLE `lime_source_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(35) DEFAULT NULL,
  `message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_source_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_survey_254951`
--

DROP TABLE IF EXISTS `lime_survey_254951`;
CREATE TABLE `lime_survey_254951` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) NOT NULL,
  `seed` varchar(31) DEFAULT NULL,
  `ipaddr` text DEFAULT NULL,
  `254951X1X1` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_survey_token_254951_27942` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_survey_254951`
--

INSERT INTO `lime_survey_254951` (`id`,`token`,`submitdate`,`lastpage`,`startlanguage`,`seed`,`ipaddr`,`254951X1X1`) VALUES
(1, NULL, '1980-01-01 00:00:00', 1, 'ru', '1675103768', '127.0.0.1', 'апап');


-- --------------------------------------------------------

--
-- Table structure for table `lime_survey_254951_timings`
--

DROP TABLE IF EXISTS `lime_survey_254951_timings`;
CREATE TABLE `lime_survey_254951_timings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interviewtime` float DEFAULT NULL,
  `254951X1time` float DEFAULT NULL,
  `254951X1X1time` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_survey_254951_timings`
--

INSERT INTO `lime_survey_254951_timings` (`id`,`interviewtime`,`254951X1time`,`254951X1X1time`) VALUES
(1, 4.69, 4.69, NULL);


-- --------------------------------------------------------

--
-- Table structure for table `lime_survey_links`
--

DROP TABLE IF EXISTS `lime_survey_links`;
CREATE TABLE `lime_survey_links` (
  `participant_id` varchar(50) NOT NULL,
  `token_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_invited` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`token_id`,`survey_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_survey_links`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_survey_url_parameters`
--

DROP TABLE IF EXISTS `lime_survey_url_parameters`;
CREATE TABLE `lime_survey_url_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `parameter` varchar(50) NOT NULL,
  `targetqid` int(11) DEFAULT NULL,
  `targetsqid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_survey_url_parameters`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveymenu`
--

DROP TABLE IF EXISTS `lime_surveymenu`;
CREATE TABLE `lime_surveymenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `survey_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0,
  `level` int(11) DEFAULT 0,
  `title` varchar(168) NOT NULL DEFAULT '',
  `position` varchar(192) NOT NULL DEFAULT 'side',
  `description` text DEFAULT NULL,
  `showincollapse` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 0,
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_surveymenu_name` (`name`),
  KEY `lime_idx2_surveymenu` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveymenu`
--

INSERT INTO `lime_surveymenu` (`id`,`parent_id`,`survey_id`,`user_id`,`name`,`ordering`,`level`,`title`,`position`,`description`,`showincollapse`,`active`,`changed_at`,`changed_by`,`created_at`,`created_by`) VALUES
(1, NULL, NULL, NULL, 'settings', 1, 0, 'Survey settings', 'side', 'Survey settings', 1, 1, '2023-04-20 07:23:50', 0, '2023-04-20 07:23:50', 0),
(2, NULL, NULL, NULL, 'mainmenu', 2, 0, 'Survey menu', 'side', 'Main survey menu', 1, 1, '2023-04-20 07:23:50', 0, '2023-04-20 07:23:50', 0),
(3, NULL, NULL, NULL, 'quickmenu', 3, 0, 'Quick menu', 'collapsed', 'Quick menu', 0, 1, '2023-04-20 07:23:50', 0, '2023-04-20 07:23:50', 0);


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveymenu_entries`
--

DROP TABLE IF EXISTS `lime_surveymenu_entries`;
CREATE TABLE `lime_surveymenu_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0,
  `name` varchar(168) DEFAULT '',
  `title` varchar(168) NOT NULL DEFAULT '',
  `menu_title` varchar(168) NOT NULL DEFAULT '',
  `menu_description` text DEFAULT NULL,
  `menu_icon` varchar(192) NOT NULL DEFAULT '',
  `menu_icon_type` varchar(192) NOT NULL DEFAULT '',
  `menu_class` varchar(192) NOT NULL DEFAULT '',
  `menu_link` varchar(192) NOT NULL DEFAULT '',
  `action` varchar(192) NOT NULL DEFAULT '',
  `template` varchar(192) NOT NULL DEFAULT '',
  `partial` varchar(192) NOT NULL DEFAULT '',
  `classes` varchar(192) NOT NULL DEFAULT '',
  `permission` varchar(192) NOT NULL DEFAULT '',
  `permission_grade` varchar(192) DEFAULT NULL,
  `data` mediumtext DEFAULT NULL,
  `getdatamethod` varchar(192) NOT NULL DEFAULT '',
  `language` varchar(32) NOT NULL DEFAULT 'en-GB',
  `showincollapse` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 0,
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lime_surveymenu_entries_name` (`name`),
  KEY `lime_idx1_surveymenu_entries` (`menu_id`),
  KEY `lime_idx5_surveymenu_entries` (`menu_title`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveymenu_entries`
--

INSERT INTO `lime_surveymenu_entries` (`id`,`menu_id`,`user_id`,`ordering`,`name`,`title`,`menu_title`,`menu_description`,`menu_icon`,`menu_icon_type`,`menu_class`,`menu_link`,`action`,`template`,`partial`,`classes`,`permission`,`permission_grade`,`data`,`getdatamethod`,`language`,`showincollapse`,`active`,`changed_at`,`changed_by`,`created_at`,`created_by`) VALUES
(1, 1, NULL, 1, 'overview', 'Survey overview', 'Overview', 'Open the general survey overview', 'ri-bar-chart-horizontal-line', 'remix', '', 'surveyAdministration/view', '', '', '', '', '', '', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(2, 1, NULL, 2, 'generalsettings', 'General survey settings', 'General settings', 'Open general survey settings', 'ri-tools-line', 'remix', '', '', 'updatesurveylocalesettings_generalsettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_generaloptions_panel', '', 'surveysettings', 'read', NULL, 'generalTabEditSurvey', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(3, 1, NULL, 3, 'surveytexts', 'Survey text elements', 'Text elements', 'Survey text elements', 'ri-text-spacing', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/tab_edit_view', '', 'surveylocale', 'read', NULL, 'getTextEditData', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(4, 1, NULL, 4, 'datasecurity', 'Privacy policy settings', 'Privacy policy', 'Edit privacy policy settings', 'ri-shield-line', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/tab_edit_view_datasecurity', '', 'surveylocale', 'read', NULL, 'getDataSecurityEditData', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(5, 1, NULL, 5, 'theme_options', 'Theme options', 'Theme options', 'Edit theme options for this survey', 'ri-contrast-drop-fill', 'remix', '', 'themeOptions/updateSurvey', '', '', '', '', 'surveysettings', 'update', '{\"render\": {\"link\": { \"pjaxed\": true, \"data\": {\"surveyid\": [\"survey\",\"sid\"], \"gsid\":[\"survey\",\"gsid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(6, 1, NULL, 6, 'presentation', 'Presentation & navigation settings', 'Presentation', 'Edit presentation and navigation settings', 'ri-slideshow-line', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_presentation_panel', '', 'surveylocale', 'read', NULL, 'tabPresentationNavigation', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(7, 1, NULL, 7, 'tokens', 'Survey participant settings', 'Participant settings', 'Set additional options for survey participants', 'ri-body-scan-fill', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_tokens_panel', '', 'surveylocale', 'read', NULL, 'tabTokens', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(8, 1, NULL, 8, 'notification', 'Notification and data management settings', 'Notifications & data', 'Edit settings for notification and data management', 'ri-notification-line', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_notification_panel', '', 'surveylocale', 'read', NULL, 'tabNotificationDataManagement', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(9, 1, NULL, 9, 'publication', 'Publication & access control settings', 'Publication & access', 'Edit settings for publication and access control', 'ri-key-line', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_publication_panel', '', 'surveylocale', 'read', NULL, 'tabPublicationAccess', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(10, 1, NULL, 10, 'surveypermissions', 'Edit survey permissions', 'Survey permissions', 'Edit permissions for this survey', 'ri-lock-password-line', 'remix', '', 'surveyPermissions/index', '', '', '', '', 'surveysecurity', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(11, 2, NULL, 1, 'listQuestions', 'Question list', 'Question list', 'List questions', '', 'remix', '', 'questionAdministration/listQuestions', '', '', '', '', 'surveycontent', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(12, 2, NULL, 2, 'listQuestionGroups', 'Group list', 'Group list', 'List question groups', '', 'remix', '', 'questionGroupsAdministration/listquestiongroups', '', '', '', '', 'surveycontent', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(13, 2, NULL, 3, 'reorder', 'Reorder questions & groups', 'Reorder questions & groups', 'Reorder questions & groups', '', 'remix', '', 'surveyAdministration/organize/', '', '', '', '', 'surveycontent', 'update', '{\"render\": {\"isActive\": false, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(14, 2, NULL, 4, 'participants', 'Survey participants', 'Survey participants', 'Go to survey participant and token settings', '', 'remix', '', 'admin/tokens/sa/index/', '', '', '', '', 'tokens', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(15, 2, NULL, 5, 'emailtemplates', 'Email templates', 'Email templates', 'Edit the templates for invitation, reminder and registration emails', '', 'remix', '', 'admin/emailtemplates/sa/index/', '', '', '', '', 'surveylocale', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(16, 2, NULL, 6, 'failedemail', 'Failed email notifications', 'Failed email notifications', 'View and resend failed email notifications', '', 'remix', '', 'failedEmail/index/', '', '', '', '', 'surveylocale', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(17, 2, NULL, 7, 'quotas', 'Edit quotas', 'Quotas', 'Edit quotas for this survey.', '', 'remix', '', 'quotas/index/', '', '', '', '', 'quotas', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(18, 2, NULL, 8, 'assessments', 'Edit assessments', 'Assessments', 'Edit and look at the assessements for this survey.', '', 'remix', '', 'assessment/index', '', '', '', '', 'assessments', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(19, 2, NULL, 9, 'panelintegration', 'Edit survey panel integration', 'Panel integration', 'Define panel integrations for your survey', '', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_integration_panel', '', 'surveylocale', 'read', '{\"render\": {\"link\": { \"pjaxed\": false}}}', 'tabPanelIntegration', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(20, 2, NULL, 10, 'responses', 'Responses', 'Responses', 'Responses', '', 'remix', '', 'responses/browse/', '', '', '', '', 'responses', 'read', '{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyId\": [\"survey\", \"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(21, 2, NULL, 11, 'statistics', 'Statistics', 'Statistics', 'Statistics', '', 'remix', '', 'admin/statistics/sa/index/', '', '', '', '', 'statistics', 'read', '{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(22, 2, NULL, 12, 'resources', 'Add/edit resources (files/images) for this survey', 'Resources', 'Add/edit resources (files/images) for this survey', '', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_resources_panel', '', 'surveylocale', 'read', '{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', 'tabResourceManagement', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(23, 2, NULL, 13, 'plugins', 'Simple plugin settings', 'Simple plugins', 'Edit simple plugin settings', '', 'remix', '', '', 'updatesurveylocalesettings', 'editLocalSettings_main_view', '/admin/survey/subview/accordion/_plugins_panel', '', 'surveysettings', 'read', '{\"render\": {\"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', 'pluginTabSurvey', 'en-GB', 0, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(24, 3, NULL, 1, 'activateSurvey', 'Activate survey', 'Activate survey', 'Activate survey', 'ri-play-fill', 'remix', '', 'surveyAdministration/activate', '', '', '', '', 'surveyactivation', 'update', '{\"render\": {\"isActive\": false, \"link\": {\"data\": {\"iSurveyID\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(25, 3, NULL, 2, 'deactivateSurvey', 'Stop survey', 'Stop survey', 'Stop this survey', 'ri-stop-fill', 'remix', '', 'surveyAdministration/deactivate', '', '', '', '', 'surveyactivation', 'update', '{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(26, 3, NULL, 3, 'testSurvey', 'Go to survey', 'Go to survey', 'Go to survey', 'ri-settings-5-fill', 'remix', '', 'survey/index/', '', '', '', '', '', '', '{\"render\": {\"link\": {\"external\": true, \"data\": {\"sid\": [\"survey\",\"sid\"], \"newtest\": \"Y\", \"lang\": [\"survey\",\"language\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(27, 3, NULL, 4, 'surveyLogicFile', 'Survey logic file', 'Survey logic file', 'Survey logic file', 'ri-git-branch-fill', 'remix', '', 'admin/expressions/sa/survey_logic_file/', '', '', '', '', 'surveycontent', 'read', '{\"render\": { \"link\": {\"data\": {\"sid\": [\"survey\",\"sid\"]}}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0),
(28, 3, NULL, 5, 'cpdb', 'Central participant database', 'Central participant database', 'Central participant database', 'ri-group-fill', 'remix', '', 'admin/participants/sa/displayParticipants', '', '', '', '', 'tokens', 'read', '{\"render\": {\"link\": {}}}', '', 'en-GB', 1, 1, '2023-04-20 07:23:51', 0, '2023-04-20 07:23:51', 0);


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveys`
--

DROP TABLE IF EXISTS `lime_surveys`;
CREATE TABLE `lime_surveys` (
  `sid` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `gsid` int(11) DEFAULT 1,
  `admin` varchar(50) DEFAULT NULL,
  `active` varchar(1) NOT NULL DEFAULT 'N',
  `expires` datetime DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `adminemail` varchar(254) DEFAULT NULL,
  `anonymized` varchar(1) NOT NULL DEFAULT 'N',
  `format` varchar(1) DEFAULT NULL,
  `savetimings` varchar(1) NOT NULL DEFAULT 'N',
  `template` varchar(100) DEFAULT 'default',
  `language` varchar(50) DEFAULT NULL,
  `additional_languages` text DEFAULT NULL,
  `datestamp` varchar(1) NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) NOT NULL DEFAULT 0,
  `autoredirect` varchar(1) NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) NOT NULL DEFAULT 'N',
  `ipanonymize` varchar(1) NOT NULL DEFAULT 'N',
  `refurl` varchar(1) NOT NULL DEFAULT 'N',
  `datecreated` datetime DEFAULT NULL,
  `showsurveypolicynotice` int(11) DEFAULT 0,
  `publicstatistics` varchar(1) NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) NOT NULL DEFAULT 'Y',
  `sendconfirmation` varchar(1) NOT NULL DEFAULT 'Y',
  `tokenanswerspersistence` varchar(1) NOT NULL DEFAULT 'N',
  `assessments` varchar(1) NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) NOT NULL DEFAULT 'N',
  `usetokens` varchar(1) NOT NULL DEFAULT 'N',
  `bounce_email` varchar(254) DEFAULT NULL,
  `attributedescriptions` mediumtext DEFAULT NULL,
  `emailresponseto` text DEFAULT NULL,
  `emailnotificationto` text DEFAULT NULL,
  `tokenlength` int(11) NOT NULL DEFAULT 15,
  `showxquestions` varchar(1) DEFAULT 'Y',
  `showgroupinfo` varchar(1) DEFAULT 'B',
  `shownoanswer` varchar(1) DEFAULT 'Y',
  `showqnumcode` varchar(1) DEFAULT 'X',
  `bouncetime` int(11) DEFAULT NULL,
  `bounceprocessing` varchar(1) DEFAULT 'N',
  `bounceaccounttype` varchar(4) DEFAULT NULL,
  `bounceaccounthost` varchar(200) DEFAULT NULL,
  `bounceaccountpass` text DEFAULT NULL,
  `bounceaccountencryption` varchar(3) DEFAULT NULL,
  `bounceaccountuser` varchar(200) DEFAULT NULL,
  `showwelcome` varchar(1) DEFAULT 'Y',
  `showprogress` varchar(1) DEFAULT 'Y',
  `questionindex` int(11) NOT NULL DEFAULT 0,
  `navigationdelay` int(11) NOT NULL DEFAULT 0,
  `nokeyboard` varchar(1) DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) DEFAULT 'N',
  `googleanalyticsstyle` varchar(1) DEFAULT NULL,
  `googleanalyticsapikey` varchar(25) DEFAULT NULL,
  `tokenencryptionoptions` text DEFAULT NULL,
  PRIMARY KEY (`sid`),
  KEY `lime_idx1_surveys` (`owner_id`),
  KEY `lime_idx2_surveys` (`gsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveys`
--

INSERT INTO `lime_surveys` (`sid`,`owner_id`,`gsid`,`admin`,`active`,`expires`,`startdate`,`adminemail`,`anonymized`,`format`,`savetimings`,`template`,`language`,`additional_languages`,`datestamp`,`usecookie`,`allowregister`,`allowsave`,`autonumber_start`,`autoredirect`,`allowprev`,`printanswers`,`ipaddr`,`ipanonymize`,`refurl`,`datecreated`,`showsurveypolicynotice`,`publicstatistics`,`publicgraphs`,`listpublic`,`htmlemail`,`sendconfirmation`,`tokenanswerspersistence`,`assessments`,`usecaptcha`,`usetokens`,`bounce_email`,`attributedescriptions`,`emailresponseto`,`emailnotificationto`,`tokenlength`,`showxquestions`,`showgroupinfo`,`shownoanswer`,`showqnumcode`,`bouncetime`,`bounceprocessing`,`bounceaccounttype`,`bounceaccounthost`,`bounceaccountpass`,`bounceaccountencryption`,`bounceaccountuser`,`showwelcome`,`showprogress`,`questionindex`,`navigationdelay`,`nokeyboard`,`alloweditaftercompletion`,`googleanalyticsstyle`,`googleanalyticsapikey`,`tokenencryptionoptions`) VALUES
(254951, 1, 1, 'inherit', 'Y', NULL, NULL, 'inherit', 'N', 'I', 'Y', 'inherit', 'ru', '', 'N', 'Y', 'I', 'I', 0, 'I', 'I', 'I', 'Y', 'N', 'N', '2023-04-20 08:42:37', 0, 'I', 'I', 'Y', 'I', 'I', 'I', 'Y', 'E', 'N', 'inherit', NULL, 'inherit', 'inherit', -1, 'I', 'I', 'I', 'I', NULL, 'N', NULL, NULL, NULL, NULL, NULL, 'I', 'I', -1, -1, 'I', 'I', '', '', '{ \"enabled\":\"Y\",\"columns\":{ \"firstname\":\"N\",\"lastname\":\"N\",\"email\":\"N\" } }'),
(779317, 1, 1, 'inherit', 'N', '2023-04-25 17:17:48', NULL, 'inherit', 'N', 'I', 'Y', 'inherit', 'ru', '', 'Y', 'Y', 'Y', 'I', 1, 'I', 'I', 'I', 'Y', 'N', 'Y', '2023-04-25 08:23:27', 0, 'Y', 'Y', 'Y', 'I', 'I', 'Y', 'Y', 'E', 'N', 'inherit', '[]', 'inherit', 'inherit', -1, 'I', 'I', 'I', 'I', NULL, 'N', NULL, NULL, NULL, NULL, NULL, 'Y', 'I', 1, -1, 'I', 'I', '', '', '{ \"enabled\":\"Y\",\"columns\":{ \"firstname\":\"N\",\"lastname\":\"N\",\"email\":\"N\" } }');


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveys_groups`
--

DROP TABLE IF EXISTS `lime_surveys_groups`;
CREATE TABLE `lime_surveys_groups` (
  `gsid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `template` varchar(128) DEFAULT 'default',
  `description` text DEFAULT NULL,
  `sortorder` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `alwaysavailable` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`gsid`),
  KEY `lime_idx1_surveys_groups` (`name`),
  KEY `lime_idx2_surveys_groups` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveys_groups`
--

INSERT INTO `lime_surveys_groups` (`gsid`,`name`,`title`,`template`,`description`,`sortorder`,`owner_id`,`parent_id`,`alwaysavailable`,`created`,`modified`,`created_by`) VALUES
(1, 'default', 'Default', NULL, 'Default survey group', 0, 1, NULL, NULL, '2023-04-20 07:23:51', '2023-04-20 07:23:51', 1);


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveys_groupsettings`
--

DROP TABLE IF EXISTS `lime_surveys_groupsettings`;
CREATE TABLE `lime_surveys_groupsettings` (
  `gsid` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `admin` varchar(50) DEFAULT NULL,
  `adminemail` varchar(254) DEFAULT NULL,
  `anonymized` varchar(1) NOT NULL DEFAULT 'N',
  `format` varchar(1) DEFAULT NULL,
  `savetimings` varchar(1) NOT NULL DEFAULT 'N',
  `template` varchar(100) DEFAULT 'default',
  `datestamp` varchar(1) NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) DEFAULT 0,
  `autoredirect` varchar(1) NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) NOT NULL DEFAULT 'N',
  `ipanonymize` varchar(1) NOT NULL DEFAULT 'N',
  `refurl` varchar(1) NOT NULL DEFAULT 'N',
  `showsurveypolicynotice` int(11) DEFAULT 0,
  `publicstatistics` varchar(1) NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) NOT NULL DEFAULT 'Y',
  `sendconfirmation` varchar(1) NOT NULL DEFAULT 'Y',
  `tokenanswerspersistence` varchar(1) NOT NULL DEFAULT 'N',
  `assessments` varchar(1) NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) NOT NULL DEFAULT 'N',
  `bounce_email` varchar(254) DEFAULT NULL,
  `attributedescriptions` text DEFAULT NULL,
  `emailresponseto` text DEFAULT NULL,
  `emailnotificationto` text DEFAULT NULL,
  `tokenlength` int(11) DEFAULT 15,
  `showxquestions` varchar(1) DEFAULT 'Y',
  `showgroupinfo` varchar(1) DEFAULT 'B',
  `shownoanswer` varchar(1) DEFAULT 'Y',
  `showqnumcode` varchar(1) DEFAULT 'X',
  `showwelcome` varchar(1) DEFAULT 'Y',
  `showprogress` varchar(1) DEFAULT 'Y',
  `questionindex` int(11) DEFAULT 0,
  `navigationdelay` int(11) DEFAULT 0,
  `nokeyboard` varchar(1) DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) DEFAULT 'N',
  PRIMARY KEY (`gsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveys_groupsettings`
--

INSERT INTO `lime_surveys_groupsettings` (`gsid`,`owner_id`,`admin`,`adminemail`,`anonymized`,`format`,`savetimings`,`template`,`datestamp`,`usecookie`,`allowregister`,`allowsave`,`autonumber_start`,`autoredirect`,`allowprev`,`printanswers`,`ipaddr`,`ipanonymize`,`refurl`,`showsurveypolicynotice`,`publicstatistics`,`publicgraphs`,`listpublic`,`htmlemail`,`sendconfirmation`,`tokenanswerspersistence`,`assessments`,`usecaptcha`,`bounce_email`,`attributedescriptions`,`emailresponseto`,`emailnotificationto`,`tokenlength`,`showxquestions`,`showgroupinfo`,`shownoanswer`,`showqnumcode`,`showwelcome`,`showprogress`,`questionindex`,`navigationdelay`,`nokeyboard`,`alloweditaftercompletion`) VALUES
(0, 1, 'Administrator', 'smagulovabilai7@gmail.com', 'N', 'G', 'N', 'fruity', 'N', 'N', 'N', 'Y', 0, 'N', 'N', 'N', 'N', 'N', 'N', 0, 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N', NULL, NULL, NULL, NULL, 15, 'Y', 'B', 'Y', 'X', 'Y', 'Y', 0, 0, 'N', 'N'),
(1, -1, 'inherit', 'inherit', 'I', 'I', 'I', 'inherit', 'I', 'I', 'I', 'I', 0, 'I', 'I', 'I', 'I', 'I', 'I', 0, 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'E', 'inherit', NULL, 'inherit', 'inherit', -1, 'I', 'I', 'I', 'I', 'I', 'I', -1, -1, 'I', 'I');


-- --------------------------------------------------------

--
-- Table structure for table `lime_surveys_languagesettings`
--

DROP TABLE IF EXISTS `lime_surveys_languagesettings`;
CREATE TABLE `lime_surveys_languagesettings` (
  `surveyls_survey_id` int(11) NOT NULL,
  `surveyls_language` varchar(45) NOT NULL DEFAULT 'en',
  `surveyls_title` varchar(200) NOT NULL,
  `surveyls_description` mediumtext DEFAULT NULL,
  `surveyls_welcometext` mediumtext DEFAULT NULL,
  `surveyls_endtext` mediumtext DEFAULT NULL,
  `surveyls_policy_notice` mediumtext DEFAULT NULL,
  `surveyls_policy_error` text DEFAULT NULL,
  `surveyls_policy_notice_label` varchar(192) DEFAULT NULL,
  `surveyls_url` text DEFAULT NULL,
  `surveyls_urldescription` varchar(255) DEFAULT NULL,
  `surveyls_email_invite_subj` varchar(255) DEFAULT NULL,
  `surveyls_email_invite` mediumtext DEFAULT NULL,
  `surveyls_email_remind_subj` varchar(255) DEFAULT NULL,
  `surveyls_email_remind` mediumtext DEFAULT NULL,
  `surveyls_email_register_subj` varchar(255) DEFAULT NULL,
  `surveyls_email_register` mediumtext DEFAULT NULL,
  `surveyls_email_confirm_subj` varchar(255) DEFAULT NULL,
  `surveyls_email_confirm` mediumtext DEFAULT NULL,
  `surveyls_dateformat` int(11) NOT NULL DEFAULT 1,
  `surveyls_attributecaptions` text DEFAULT NULL,
  `surveyls_alias` varchar(100) DEFAULT NULL,
  `email_admin_notification_subj` varchar(255) DEFAULT NULL,
  `email_admin_notification` mediumtext DEFAULT NULL,
  `email_admin_responses_subj` varchar(255) DEFAULT NULL,
  `email_admin_responses` mediumtext DEFAULT NULL,
  `surveyls_numberformat` int(11) NOT NULL DEFAULT 0,
  `attachments` text DEFAULT NULL,
  PRIMARY KEY (`surveyls_survey_id`,`surveyls_language`),
  KEY `lime_idx1_surveys_languagesettings` (`surveyls_title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_surveys_languagesettings`
--

INSERT INTO `lime_surveys_languagesettings` (`surveyls_survey_id`,`surveyls_language`,`surveyls_title`,`surveyls_description`,`surveyls_welcometext`,`surveyls_endtext`,`surveyls_policy_notice`,`surveyls_policy_error`,`surveyls_policy_notice_label`,`surveyls_url`,`surveyls_urldescription`,`surveyls_email_invite_subj`,`surveyls_email_invite`,`surveyls_email_remind_subj`,`surveyls_email_remind`,`surveyls_email_register_subj`,`surveyls_email_register`,`surveyls_email_confirm_subj`,`surveyls_email_confirm`,`surveyls_dateformat`,`surveyls_attributecaptions`,`surveyls_alias`,`email_admin_notification_subj`,`email_admin_notification`,`email_admin_responses_subj`,`email_admin_responses`,`surveyls_numberformat`,`attachments`) VALUES
(254951, 'ru', 'Тест', '', '', '', '', NULL, '', '', '', 'Приглашение к участию в опросе', 'Уважаемый(-ая) {FIRSTNAME},<br />\n<br />\nприглашаем Вас принять участие в опросе.<br />\n<br />\nОпрос называется<br />\n«‎{SURVEYNAME}»<br />\n<br />\n«‎{SURVEYDESCRIPTION} »<br />\n<br />\nДля участия перейдите по ссылке.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nНажмите здесь для прохождения опроса:<br />\n{SURVEYURL}<br />\n<br />\nЕсли Вы не хотите участвовать в этом опросе и не хотите больше получать приглашения, перейдите, пожалуйста по следующей ссылке:<br />\n{OPTOUTURL}<br />\n<br />\nЕсли вы внесены в черный список, но хотите участвовать в этом опросе и получать приглашения, перейдите, пожалуйста, по следующей ссылке:<br />\n{OPTINURL}', 'Напоминание об участии в опросе', 'Здравствуйте {FIRSTNAME}!<br />\n<br />\nНедавно мы приглашали Вас принять участие в опросе.<br />\n<br />\nПо нашей информации, Вы все еще не прошли опрос. Мы напоминаем Вам, что этот опрос всё ещё доступен, и Вы можете принять в нем участие.<br />\n<br />\nНазвание опроса:<br />\n\"{SURVEYNAME}\"<br />\n<br />\n\"{SURVEYDESCRIPTION}\"<br />\n<br />\nДля того, чтобы принять участие, пожалуйста, перейдите по ссылке.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nПерейдите по ссылке, чтобы принять участие в опросе:<br />\n{SURVEYURL}<br />\n<br />\nЕсли Вы не хотите участвовать в этом опросе и не хотите больше получать приглашения, перейдите, пожалуйста по следующей ссылке:<br />\n{OPTOUTURL}', 'Подтверждение регистрации в опросе', 'Уважаемый {FIRSTNAME}!<br />\n<br />\nВы, либо кто-то другой, используя Ваш адрес E-mail, зарегистрировался для участия в опросе {SURVEYNAME}.<br />\n<br />\nДля участия в этом опросе перейдите по следующей ссылке:<br />\n<br />\n{SURVEYURL}<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME}', 'Подтверждение вашего участия в нашем опросе', 'Уважаемый(-ая) {FIRSTNAME}!<br />\n<br />\nНастоящим письмом мы подтверждаем, что вы прошли опрос под названием {SURVEYNAME} и что ваши ответы были сохранены. Благодарим за участие.<br />\n<br />\nЕсли у вас возникнут вопросы по поводу этого письма, свяжитесь с {ADMINNAME} по {ADMINEMAIL}.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME}', 1, NULL, NULL, 'Новый ответ для опроса {SURVEYNAME}', 'Здравствуйте,<br />\n<br />\nНовые ответы были добавлены для опроса \'{SURVEYNAME}\'.<br />\n<br />\nНажмите на ссылку, чтобы увидеть ответы этого респондента:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nИзменить ответы этого респондента можно тут:<br />\n{EDITRESPONSEURL}<br />\n<br />\nПосмотреть статистику ответов можно тут:<br />\n{STATISTICSURL}', 'Отправка ответа для опроса {SURVEYNAME} с результатами', 'Здравствуйте,<br />\n<br />\nНовые ответы были добавлены в опросе \'{SURVEYNAME}\'.<br />\n<br />\nНажмите на ссылку, чтобы увидеть ответы этого респондента:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nИзменить ответы этого респондента можно тут:<br />\n{EDITRESPONSEURL}<br />\n<br />\nПосмотреть статистику можно тут:<br />\n{STATISTICSURL}<br />\n<br />\nОтветы были даны следующим участником:<br />\n{ANSWERTABLE}', 1, NULL),
(779317, 'ru', 'test', '', 'Приветственное сообщение', 'результатт', '', NULL, '', '', '', 'Приглашение к участию в опросе', 'Уважаемый(-ая) {FIRSTNAME},<br />\n<br />\nприглашаем Вас принять участие в опросе.<br />\n<br />\nОпрос называется<br />\n«‎{SURVEYNAME}»<br />\n<br />\n«‎{SURVEYDESCRIPTION} »<br />\n<br />\nДля участия перейдите по ссылке.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nНажмите здесь для прохождения опроса:<br />\n{SURVEYURL}<br />\n<br />\nЕсли Вы не хотите участвовать в этом опросе и не хотите больше получать приглашения, перейдите, пожалуйста по следующей ссылке:<br />\n{OPTOUTURL}<br />\n<br />\nЕсли вы внесены в черный список, но хотите участвовать в этом опросе и получать приглашения, перейдите, пожалуйста, по следующей ссылке:<br />\n{OPTINURL}', 'Напоминание об участии в опросе', 'Здравствуйте {FIRSTNAME}!<br />\n<br />\nНедавно мы приглашали Вас принять участие в опросе.<br />\n<br />\nПо нашей информации, Вы все еще не прошли опрос. Мы напоминаем Вам, что этот опрос всё ещё доступен, и Вы можете принять в нем участие.<br />\n<br />\nНазвание опроса:<br />\n\"{SURVEYNAME}\"<br />\n<br />\n\"{SURVEYDESCRIPTION}\"<br />\n<br />\nДля того, чтобы принять участие, пожалуйста, перейдите по ссылке.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nПерейдите по ссылке, чтобы принять участие в опросе:<br />\n{SURVEYURL}<br />\n<br />\nЕсли Вы не хотите участвовать в этом опросе и не хотите больше получать приглашения, перейдите, пожалуйста по следующей ссылке:<br />\n{OPTOUTURL}', 'Подтверждение регистрации в опросе', 'Уважаемый {FIRSTNAME}!<br />\n<br />\nВы, либо кто-то другой, используя Ваш адрес E-mail, зарегистрировался для участия в опросе {SURVEYNAME}.<br />\n<br />\nДля участия в этом опросе перейдите по следующей ссылке:<br />\n<br />\n{SURVEYURL}<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME}', 'Подтверждение вашего участия в нашем опросе', 'Уважаемый(-ая) {FIRSTNAME}!<br />\n<br />\nНастоящим письмом мы подтверждаем, что вы прошли опрос под названием {SURVEYNAME} и что ваши ответы были сохранены. Благодарим за участие.<br />\n<br />\nЕсли у вас возникнут вопросы по поводу этого письма, свяжитесь с {ADMINNAME} по {ADMINEMAIL}.<br />\n<br />\nС уважением,<br />\n<br />\n{ADMINNAME}', 1, '{\"attribute_1\":\"\"}', '', 'Новый ответ для опроса {SURVEYNAME}', 'Здравствуйте,<br />\n<br />\nНовые ответы были добавлены для опроса \'{SURVEYNAME}\'.<br />\n<br />\nНажмите на ссылку, чтобы увидеть ответы этого респондента:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nИзменить ответы этого респондента можно тут:<br />\n{EDITRESPONSEURL}<br />\n<br />\nПосмотреть статистику ответов можно тут:<br />\n{STATISTICSURL}', 'Отправка ответа для опроса {SURVEYNAME} с результатами', 'Здравствуйте,<br />\n<br />\nНовые ответы были добавлены в опросе \'{SURVEYNAME}\'.<br />\n<br />\nНажмите на ссылку, чтобы увидеть ответы этого респондента:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nИзменить ответы этого респондента можно тут:<br />\n{EDITRESPONSEURL}<br />\n<br />\nПосмотреть статистику можно тут:<br />\n{STATISTICSURL}<br />\n<br />\nОтветы были даны следующим участником:<br />\n{ANSWERTABLE}', 0, NULL);


-- --------------------------------------------------------

--
-- Table structure for table `lime_template_configuration`
--

DROP TABLE IF EXISTS `lime_template_configuration`;
CREATE TABLE `lime_template_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(150) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `gsid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `files_css` text DEFAULT NULL,
  `files_js` text DEFAULT NULL,
  `files_print_css` text DEFAULT NULL,
  `options` text DEFAULT NULL,
  `cssframework_name` varchar(45) DEFAULT NULL,
  `cssframework_css` mediumtext DEFAULT NULL,
  `cssframework_js` mediumtext DEFAULT NULL,
  `packages_to_load` text DEFAULT NULL,
  `packages_ltr` text DEFAULT NULL,
  `packages_rtl` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_template_configuration` (`template_name`),
  KEY `lime_idx2_template_configuration` (`sid`),
  KEY `lime_idx3_template_configuration` (`gsid`),
  KEY `lime_idx4_template_configuration` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_template_configuration`
--

INSERT INTO `lime_template_configuration` (`id`,`template_name`,`sid`,`gsid`,`uid`,`files_css`,`files_js`,`files_print_css`,`options`,`cssframework_name`,`cssframework_css`,`cssframework_js`,`packages_to_load`,`packages_ltr`,`packages_rtl`) VALUES
(1, 'vanilla', NULL, NULL, NULL, '{\"add\":[\"css/base.css\",\"css/theme.css\",\"css/noTablesOnMobile.css\",\"css/custom.css\"]}', '{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}', '{\"add\":[\"css/print_theme.css\"]}', '{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"container\":\"on\", \"hideprivacyinfo\": \"off\", \"brandlogofile\":\"themes/survey/vanilla/files/logo.png\",\"font\":\"noto\", \"showpopups\":\"1\", \"showclearall\":\"off\", \"questionhelptextposition\":\"top\"}', 'bootstrap', '{}', '', '{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}', NULL, NULL),
(2, 'fruity', NULL, NULL, NULL, '{\"add\":[\"css/ajaxify.css\",\"css/animate.css\",\"css/variations/sea_green.css\",\"css/theme.css\",\"css/custom.css\"]}', '{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}', '{\"add\":[\"css/print_theme.css\"]}', '{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"brandlogofile\":\"themes/survey/fruity/files/logo.png\",\"container\":\"on\",\"backgroundimage\":\"off\",\"backgroundimagefile\":null,\"animatebody\":\"off\",\"bodyanimation\":\"fadeInRight\",\"bodyanimationduration\":\"500\",\"animatequestion\":\"off\",\"questionanimation\":\"flipInX\",\"questionanimationduration\":\"500\",\"animatealert\":\"off\",\"alertanimation\":\"shake\",\"alertanimationduration\":\"500\",\"font\":\"noto\",\"bodybackgroundcolor\":\"#ffffff\",\"fontcolor\":\"#444444\",\"questionbackgroundcolor\":\"#ffffff\",\"questionborder\":\"on\",\"questioncontainershadow\":\"on\",\"checkicon\":\"f00c\",\"animatecheckbox\":\"on\",\"checkboxanimation\":\"rubberBand\",\"checkboxanimationduration\":\"500\",\"animateradio\":\"on\",\"radioanimation\":\"zoomIn\",\"radioanimationduration\":\"500\",\"zebrastriping\":\"off\",\"stickymatrixheaders\":\"off\",\"greyoutselected\":\"off\",\"hideprivacyinfo\":\"off\",\"crosshover\":\"off\",\"showpopups\":\"1\", \"showclearall\":\"off\", \"questionhelptextposition\":\"top\",\"notables\":\"1\"}', 'bootstrap', '{}', '', '{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}', NULL, NULL),
(3, 'bootswatch', NULL, NULL, NULL, '{\"add\":[\"css/ajaxify.css\",\"css/theme.css\",\"css/custom.css\"]}', '{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}', '{\"add\":[\"css/print_theme.css\"]}', '{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"container\":\"on\",\"brandlogofile\":\"image::theme::files\\\\logo.png\",\"showpopups\":\"1\",\"showclearall\":\"off\",\"questionhelptextposition\":\"top\"}', 'bootstrap', '{\"replace\":[[\"css/bootstrap.css\",\"css/variations/flatly.min.css\"]]}', '', '{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}', NULL, NULL),
(4, 'копия_vanilla', NULL, NULL, NULL, '{\"add\":[\"css\\/base.css\",\"css\\/theme.css\",\"css\\/noTablesOnMobile.css\",\"css\\/custom.css\"]}', '{\"add\":[\"scripts\\/theme.js\",\"scripts\\/custom.js\"]}', '{\"add\":[\"css\\/print_theme.css\"]}', '{\"animatebody\":\"off\",\"hideprivacyinfo\":\"off\",\"container\":\"on\",\"showpopups\":\"1\",\"showclearall\":\"off\",\"questionhelptextposition\":\"top\",\"fixnumauto\":\"off\",\"brandlogo\":\"on\",\"brandlogofile\":\"image::theme::files\\\\logo.png\",\"font\":\"noto\\n            \\n       \"}', 'bootstrap', '{}', '[]', '{\"add\":[\"pjax\",\"moment\",\"font-noto\"]}', NULL, NULL),
(5, 'fruity', 254951, NULL, NULL, 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', NULL, NULL),
(6, 'fruity', NULL, 1, NULL, 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', NULL, NULL),
(7, 'копия_bootswatch', NULL, NULL, NULL, '{\"replace\":[\"css\\/theme.css\",\"css\\/custom.css\"]}', '{\"replace\":[\"scripts\\/theme.js\",\"scripts\\/custom.js\"]}', '{\"replace\":[\"css\\/print_theme.css\"]}', '{\"container\":\"on\",\"showpopups\":\"1\",\"showclearall\":\"off\",\"questionhelptextposition\":\"top\",\"fixnumauto\":\"off\",\"brandlogo\":\"on\",\"brandlogofile\":\"image::theme::files\\\\logo.png\",\"hideprivacyinfo\":\"off\",\"cssframework\":null}', 'bootstrap', '{\"replace\":[[\"css\\/bootstrap.css\",\"css\\/variations\\/flatly.min.css\"]]}', '[]', '{\"add\":[\"pjax\",\"moment\"]}', NULL, NULL),
(8, 'fruity', 779317, NULL, NULL, 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', 'inherit', NULL, NULL);


-- --------------------------------------------------------

--
-- Table structure for table `lime_templates`
--

DROP TABLE IF EXISTS `lime_templates`;
CREATE TABLE `lime_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `folder` varchar(45) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `author` varchar(150) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `author_url` varchar(255) DEFAULT NULL,
  `copyright` text DEFAULT NULL,
  `license` mediumtext DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `api_version` varchar(45) NOT NULL,
  `view_folder` varchar(45) NOT NULL,
  `files_folder` varchar(45) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `extends` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lime_idx1_templates` (`name`),
  KEY `lime_idx2_templates` (`title`),
  KEY `lime_idx3_templates` (`owner_id`),
  KEY `lime_idx4_templates` (`extends`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_templates`
--

INSERT INTO `lime_templates` (`id`,`name`,`folder`,`title`,`creation_date`,`author`,`author_email`,`author_url`,`copyright`,`license`,`version`,`api_version`,`view_folder`,`files_folder`,`description`,`last_update`,`owner_id`,`extends`) VALUES
(1, 'vanilla', 'vanilla', 'Vanilla Theme', '2023-04-20 07:23:51', 'LimeSurvey GmbH', 'info@limesurvey.org', 'https://www.limesurvey.org/', 'Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.', 'License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.', '3.0', '3.0', 'views', 'files', '<strong>LimeSurvey Bootstrap Vanilla Survey Theme</strong><br>A clean and simple base that can be used by developers to create their own Bootstrap based theme.', NULL, 1, ''),
(2, 'fruity', 'fruity', 'Fruity Theme', '2023-04-20 07:23:51', 'LimeSurvey GmbH', 'info@limesurvey.org', 'https://www.limesurvey.org/', 'Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.', 'License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.', '3.0', '3.0', 'views', 'files', '<strong>LimeSurvey Fruity Theme</strong><br>A fruity theme for a flexible use. This theme offers monochromes variations and many options for easy customizations.', NULL, 1, 'vanilla'),
(3, 'bootswatch', 'bootswatch', 'Bootswatch Theme', '2023-04-20 07:23:51', 'LimeSurvey GmbH', 'info@limesurvey.org', 'https://www.limesurvey.org/', 'Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.', 'License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.', '3.0', '3.0', 'views', 'files', '<strong>LimeSurvey Bootwatch Theme</strong><br>Based on BootsWatch Themes: <a href=\"https://bootswatch.com/3/\"\">Visit BootsWatch page</a> ', NULL, 1, 'vanilla'),
(4, 'копия_vanilla', 'копия_vanilla', 'копия_vanilla', '2023-04-20 07:33:00', 'admin', '', '', NULL, NULL, NULL, '3.0', 'views', 'files', '<strong>LimeSurvey Bootstrap Vanilla Survey Theme</strong><br>A clean and simple base that can be used by developers to create their own Bootstrap based theme.', NULL, 1, 'vanilla'),
(5, 'копия_bootswatch', 'копия_bootswatch', 'копия_bootswatch', '2023-04-21 13:30:39', 'admin', '', '', NULL, NULL, NULL, '3.0', 'views', 'files', '<strong>{{gT(\"LimeSurvey Bootwatch Theme\")}}</strong><br>{{gT(\"Based on BootsWatch Themes:\")}} <a href=\'https://bootswatch.com/3/\'>{{gT(\"Visit BootsWatch page\")}}</a> ', NULL, 1, 'bootswatch');


-- --------------------------------------------------------

--
-- Table structure for table `lime_tutorial_entries`
--

DROP TABLE IF EXISTS `lime_tutorial_entries`;
CREATE TABLE `lime_tutorial_entries` (
  `teid` int(11) NOT NULL AUTO_INCREMENT,
  `ordering` int(11) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `settings` mediumtext DEFAULT NULL,
  PRIMARY KEY (`teid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_tutorial_entries`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_tutorial_entry_relation`
--

DROP TABLE IF EXISTS `lime_tutorial_entry_relation`;
CREATE TABLE `lime_tutorial_entry_relation` (
  `teid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`teid`,`tid`),
  KEY `lime_idx1_tutorial_entry_relation` (`uid`),
  KEY `lime_idx2_tutorial_entry_relation` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_tutorial_entry_relation`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_tutorials`
--

DROP TABLE IF EXISTS `lime_tutorials`;
CREATE TABLE `lime_tutorials` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `title` varchar(192) DEFAULT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `active` int(11) DEFAULT 0,
  `settings` mediumtext DEFAULT NULL,
  `permission` varchar(128) NOT NULL,
  `permission_grade` varchar(128) NOT NULL,
  PRIMARY KEY (`tid`),
  UNIQUE KEY `lime_idx1_tutorials` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_tutorials`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_user_groups`
--

DROP TABLE IF EXISTS `lime_user_groups`;
CREATE TABLE `lime_user_groups` (
  `ugid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`ugid`),
  UNIQUE KEY `lime_idx1_user_groups` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_user_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_user_in_groups`
--

DROP TABLE IF EXISTS `lime_user_in_groups`;
CREATE TABLE `lime_user_in_groups` (
  `ugid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ugid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_user_in_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_user_in_permissionrole`
--

DROP TABLE IF EXISTS `lime_user_in_permissionrole`;
CREATE TABLE `lime_user_in_permissionrole` (
  `ptid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ptid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_user_in_permissionrole`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime_users`
--

DROP TABLE IF EXISTS `lime_users`;
CREATE TABLE `lime_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `users_name` varchar(64) NOT NULL DEFAULT '',
  `password` text NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `lang` varchar(20) DEFAULT NULL,
  `email` varchar(192) DEFAULT NULL,
  `htmleditormode` varchar(7) DEFAULT 'default',
  `templateeditormode` varchar(7) NOT NULL DEFAULT 'default',
  `questionselectormode` varchar(7) NOT NULL DEFAULT 'default',
  `one_time_pw` text DEFAULT NULL,
  `dateformat` int(11) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `validation_key` varchar(38) DEFAULT NULL,
  `validation_key_expiration` datetime DEFAULT NULL,
  `last_forgot_email_password` datetime DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `lime_idx1_users` (`users_name`),
  KEY `lime_idx2_users` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lime_users`
--

INSERT INTO `lime_users` (`uid`,`users_name`,`password`,`full_name`,`parent_id`,`lang`,`email`,`htmleditormode`,`templateeditormode`,`questionselectormode`,`one_time_pw`,`dateformat`,`last_login`,`created`,`modified`,`validation_key`,`validation_key_expiration`,`last_forgot_email_password`,`expires`) VALUES
(1, 'admin', '$2y$10$.eqeeRsX56agvqUvMLhUA.bM2VJXquc36eIB4PpSYZBDeonSDi15a', 'Administrator', 0, 'ru', 'smagulovabilai7@gmail.com', 'default', 'default', 'default', NULL, 1, '2023-04-25 17:09:35', '2023-04-20 11:25:23', '2023-04-26 12:29:40', '28q3cdbqde7q7vbuk8mt4pay9fct3s9a5axk8s', '2023-04-26 14:20:04', '2023-04-24 14:20:04', NULL),
(2, 'dummyuser_079c', '$2y$10$YUcwddZFPPlG8yaZQaBinOJCukXT.CF88rhEAnrYQ6I5JmUlsNtmO', 'dummyuser_079c', 1, 'auto', 'smagulovabilai7@gmail.com', 'default', 'default', 'default', NULL, 1, NULL, '2023-04-26 09:25:41', '2023-04-26 05:25:41', NULL, NULL, NULL, NULL);

